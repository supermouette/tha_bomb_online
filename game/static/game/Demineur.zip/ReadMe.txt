  _____                       __  __                  _   _       
 / ____|                     |  \/  |                | | | |      
| (___  _   _ _ __   ___ _ __| \  / | ___  _   _  ___| |_| |_ ___ 
 \___ \| | | | '_ \ / _ \ '__| |\/| |/ _ \| | | |/ _ \ __| __/ _ \
 ____) | |_| | |_) |  __/ |  | |  | | (_) | |_| |  __/ |_| ||  __/
|_____/ \__,_| .__/ \___|_|  |_|  |_|\___/ \__,_|\___|\__|\__\___|
             | |                                                  
             |_|                                                  


Ceci est la version 1.4 du D�mineur par Super Mouette. (22/03/2015)

Quelques optimisations sont pr�vues, notamment :
	- autre gestion des cases (JButton trop gourmand)   

Sc�nario du jeu :

	Vous �tes Bob le d�mineur, tout droit sorti du DUT d�minage.
	Vous venez d'�tre embauch�, et vous �tes face � votre premi�re mission !
	Vous allez donc devoir d�miner la grille en pla�ant des drapeaux (clic droit) pour signaler qu'une bombe est pr�sente sur une case.
	Pour d�couvrir des cases o� vous �tes certain qu'il n'y a pas de bombe, faites un clic gauche.
	Pour vous aider dans votre t�che dangereuse, le Dieu des mines vous accompagne.
		Il vous fournira deux aides : 
		La premi�re est de taille : votre premier clic est garanti sans danger ! Vous ne pouvez donc pas mourir au premier essai !
		Sa seconde aide vous permettra de terminer la grille : il s'agit des num�ros qui apparaissent sur les cases :
			Ils correspondent aux nombres de bombes adjacentes � la case (diagonales incluses) !
	Nous vous souhaitons bonne chance, Bob !
	Et n'oubliez pas, si une seule bombe venait � exploser, toutes les bombes de la grille exploseront, et vous avec !


Des questions, des remarques, des promesses de dons ?
-> loic.souverain@gmail.com <- 


  _____                       __  __                  _   _       
 / ____|                     |  \/  |                | | | |      
| (___  _   _ _ __   ___ _ __| \  / | ___  _   _  ___| |_| |_ ___ 
 \___ \| | | | '_ \ / _ \ '__| |\/| |/ _ \| | | |/ _ \ __| __/ _ \
 ____) | |_| | |_) |  __/ |  | |  | | (_) | |_| |  __/ |_| ||  __/
|_____/ \__,_| .__/ \___|_|  |_|  |_|\___/ \__,_|\___|\__|\__\___|
             | |                                                  
             |_|                                                  
